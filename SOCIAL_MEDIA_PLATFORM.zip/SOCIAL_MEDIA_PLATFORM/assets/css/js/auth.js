function login() {
alert("Logged in successfully!");
window.location.href = "index.html";
}


function signup() {
alert("Account created!");
window.location.href = "login.html";
}