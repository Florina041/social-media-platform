function createPost() {
alert("Post uploaded!");
}