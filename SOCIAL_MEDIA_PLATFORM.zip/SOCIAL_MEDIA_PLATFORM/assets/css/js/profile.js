const profilePosts = document.getElementById("profilePosts");


profilePosts.innerHTML = `
<div class='post-card'>My first post</div>
<div class='post-card'>Hello world!</div>
`;